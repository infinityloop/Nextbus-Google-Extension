function saveSettings {
	

}